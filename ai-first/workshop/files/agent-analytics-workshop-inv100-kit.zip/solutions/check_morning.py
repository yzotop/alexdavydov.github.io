"""Repeat the final exercise after extracting the reader's kit."""
import csv
from pathlib import Path

folder = Path(__file__).resolve().parent.parent / "morning"


def read(name):
    with (folder / name).open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


network_rows = read("Сеть.csv")
checks = read("Сверки.csv")
network = {int(row["магазин"]) for row in network_rows}
covered = {int(row["магазин"]) for row in checks}
if len(network) != len(network_rows) or len(covered) != len(checks) or not covered <= network:
    raise ValueError("Проверь повторяющиеся номера и принадлежность магазинов к сети.")
sales = {int(row["магазин"]) for row in checks if int(row["продажи_коп"]) != 0}
returns = {int(row["магазин"]) for row in checks if int(row["возвраты_коп"]) != 0}
affected = sales | returns
print("По продажам", len(sales), "по возвратам", len(returns))
print("В обеих группах", sorted(sales & returns))
print("Магазины с расхождениями", sorted(affected))
print(f"Среди проверенных {len(affected)} из {len(covered)} ({100*len(affected)/len(covered):.1f}%)")
print(f"Охват {len(covered)} из {len(network)}. Отсутствуют {sorted(network-covered)}")
