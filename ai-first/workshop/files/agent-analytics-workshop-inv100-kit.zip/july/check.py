"""Recompute both July scenarios using only the files in this directory."""
import csv
import hashlib
import json
from decimal import Decimal
from pathlib import Path

root = Path(__file__).resolve().parent
def read(name):
    return json.loads((root/name).read_text())
def table(name):
    with (root/(name+'.csv')).open(encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    assert rows == [{k:str(v) for k,v in record.items()} for record in read(name+'.json')['rows']]
    result = {int(r['store_id']):tuple(Decimal(r[col]) for col in ('sales','returns','net')) for r in rows}
    assert len(result)==len(rows)==24 and all(s-r==n for s,r,n in result.values())
    return result
inputs=read('inputs.json')
for file,digest in inputs['sha256'].items():
    assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest
approval=read('approval.json')
assert inputs['sha256']['plan-'+approval['approved_plan_id']+'.json']==approval['approved_plan_sha256']
actual=table('actual')
for version in ('B','A'):
    plan=table('plan-'+version)
    assert set(plan)==set(actual)==set(inputs['store_ids'])
    diffs={i:actual[i][2]-plan[i][2] for i in plan}
    first=min(diffs,key=diffs.get)
    worst=min(plan,key=lambda i:actual[i][2]/plan[i][2])
    sales=actual[first][0]-plan[first][0]
    returns=plan[first][1]-actual[first][1]
    assert sales+returns==diffs[first]
    print(version, 'сеть', sum(diffs.values()), 'магазин', first, 'вклад',diffs[first],
          'продажи',sales,'возвраты',returns,'худший процент',worst)
