"""Reproduce both Monday results and audit every matched order on the current export."""
import hashlib
import json
from pathlib import Path

from matcher import match

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_text())


def sha(name):
    return hashlib.sha256((ROOT / name).read_bytes()).hexdigest()


def main():
    release = read("release.json")
    build = release["monday_build"]
    approved = release["approval"]
    files = {name: sha(name) for name in ("matcher.py", "leading_zero.py")}
    assert files == build["files"] and files[approved["component"]] == approved["approved_sha256"]
    assert build["leading_zero_enabled"] is True
    previous = match(read("previous-payments.json"), read("previous-directory.json"), False)
    payments, orders = read("payments.json"), read("directory.json")
    control = match(payments, orders, False)
    monday = match(payments, orders, build["leading_zero_enabled"])
    expected = read("expected-orders.json")
    assert len(payments) == len(monday) and monday.keys() == expected.keys()

    def verdict(order, correct):
        return "без пары" if order is None else "верно" if order == correct else "ошибка"

    audit = []
    totals = {}
    for label, output in [("без правки", control), ("с правкой", monday)]:
        statuses = [verdict(row["order"], expected[key]) for key, row in output.items()]
        totals[label] = {s: statuses.count(s) for s in ("верно", "ошибка", "без пары")}
    for p in payments:
        key = p["id"]
        audit.append(dict(payment=key, reference=p["reference"], expected=expected[key],
                          before=control[key]["order"], after=monday[key]["order"],
                          branch=monday[key]["branch"], verdict=verdict(monday[key]["order"], expected[key])))
    return dict(build=build["id"], executed_files_sha256=files,
                enabled=build["leading_zero_enabled"],
                input_sha256={p:sha(p) for p in ("payments.json", "directory.json")},
                previous_unmatched=sum(row["order"] is None for row in previous.values()),
                monday_totals=totals, audit=audit)


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, indent=2))
