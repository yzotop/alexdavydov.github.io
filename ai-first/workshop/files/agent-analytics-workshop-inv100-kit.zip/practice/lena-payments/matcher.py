"""Match exact order references first and optionally try the approved component."""
from leading_zero import lookup


def match(payments, orders, enabled):
    result = {}
    for payment in payments:
        reference = payment["reference"]
        order = orders.get(reference)
        branch = "exact"
        if order is None:
            branch = "unmatched"
            if enabled and reference.startswith("0"):
                order = lookup(reference, orders)
                branch = "leading_zero"
        result[payment["id"]] = {"order": order, "branch": branch}
    return result
