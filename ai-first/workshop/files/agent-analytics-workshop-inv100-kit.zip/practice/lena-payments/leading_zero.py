"""Lena's synthetic component, revision 1."""
def lookup(reference, orders):
    if reference.isdecimal() and reference.startswith("0"):
        return orders.get(reference.lstrip("0") or "0")
    return None
