"""Compare saved synthetic summaries against their dated source letters."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def errors(letters, summary):
    seen = set()
    notes = []
    for entry in summary:
        source = entry["source"]
        if source in seen or source not in letters:
            notes.append(f"повтор или неизвестный источник {source}")
            continue
        seen.add(source)
        letter = letters[source]
        if entry["store"] != letter["store"]:
            notes.append(f'приписано №{entry["store"]} вместо №{letter["store"]}')
        if entry["claim"] != letter["body"]:
            notes.append(f'текст отличается от письма №{letter["store"]}')
    notes.extend(f'пропущено письмо №{letters[key]["store"]}' for key in sorted(letters.keys() - seen))
    return notes


def compare(path):
    data = json.loads(path.read_text())
    letters = {m["id"]: m for m in data["emails"]}
    assert len(letters) == len(data["emails"]) == 12
    assert {m["store"] for m in letters.values()} == set(range(1, 13))
    calls = {}
    totals = {}
    acceptable = True
    for mode, run in data["runs"].items():
        draft_errors = errors(letters, run["draft"])
        final_errors = errors(letters, run["final"])
        calls[mode] = {(c["store"], c["reason"]) for c in run["manager_calls"]}
        claims = {(c["store"], c["claim"]) for c in run["final"]}
        totals[mode] = sum(run["human_minutes"].values())
        acceptable &= (not final_errors and calls[mode] <= claims and
                       run["final_ready"] <= run["decision_at"] <= "11:00")
        print(data["date"], mode, draft_errors, final_errors, totals[mode],
              run["final_ready"], sorted(n for n, _ in calls[mode]))
    saved = totals["manual"] - totals["agent"]
    return acceptable and calls["manual"] == calls["agent"] and saved >= totals["manual"] * 0.2


if __name__ == "__main__":
    outcomes = [compare(ROOT / name) for name in ("2026-11-02.json", "2026-11-09.json")]
    print("Пробовать ещё один регион" if all(outcomes) else "Условия пилота требуют разбора")
