"""Rebuild the June exercise calculation from its three local input files."""
import json
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MONTH = "2025-06"


def ids_text(ids):
    return ", ".join(f"№{i}" for i in sorted(ids))


def calculate():
    roster = json.loads((ROOT / "roster.json").read_text())
    mailing = json.loads((ROOT / "mailings.json").read_text())
    rows = [json.loads(line) for line in (ROOT / "june.jsonl").read_text().splitlines()]
    if roster["month"] != MONTH or mailing["month"] != MONTH or any(r["month"] != MONTH for r in rows):
        raise ValueError("Периоды источников расходятся")
    network = set(roster["store_ids"])
    checked = {r["store_id"] for r in rows}
    if len(network) != len(roster["store_ids"]) or len(checked) != len(rows) or checked != network:
        raise ValueError("Реестр и завершённые сверки различаются по охвату или содержат повторы")

    sales = {r["store_id"] for r in rows if r["sales_delta_kopecks"] != 0}
    returns = {r["store_id"] for r in rows if r["returns_delta_kopecks"] != 0}
    if sales != set(mailing["sales"]) or returns != set(mailing["returns"]):
        raise ValueError("Получатели рассылки расходятся с результатами сверки")

    both = sales & returns
    affected = sales | returns
    percent = Decimal(100) * len(affected) / len(network)
    return f"""# Расчёт доли магазинов с расхождениями за июнь 2025

Учебные данные. Единица счёта — магазин. Каждая строка выгрузки соответствует завершённой сверке одного магазина. Ненулевая разница в копейках означает расхождение.

В июньском реестре {len(network)} уникальных магазинов. В выгрузке {len(rows)} сверок по {len(checked)} уникальным номерам. Наборы номеров совпадают полностью. [Реестр сети](roster.json) · [Выгрузка сверок](june.jsonl)

| Что проверили | Результат |
|---|---|
| Расхождения по продажам | {len(sales)} магазинов |
| Расхождения по возвратам | {len(returns)} магазинов |
| В обоих списках | {len(both)} магазина ({ids_text(both)}) |
| Только по продажам | {len(sales - returns)} |
| Только по возвратам | {len(returns - sales)} |
| Без расхождений | {len(network - affected)} |

Оба списка получателей по номерам совпали с соответствующими группами из выгрузки. Магазин №14 входит в обе группы и один раз в общий итог. [Списки рассылки](mailings.json)

Всего {len(sales)} + {len(returns)} − {len(both)} = {len(affected)} уникальных магазинов с расхождениями. Доля сети составляет {len(affected)} / {len(network)} × 100 = {percent:g}%.

Для повторения запустите из корня iKBAD команду `python3 -B cookbook/practice/june-reconciliation/calculate.py`. [Код расчёта](calculate.py)
"""


if __name__ == "__main__":
    print(calculate(), end="")
