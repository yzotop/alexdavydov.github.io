# Поля ASOS Digital Experiments Dataset

Строка содержит накопленные к указанному времени агрегаты. experiment_id обозначает эксперимент, variant_id — вариант внутри эксперимента, metric_id — анонимизированную метрику. time_since_start — время от старта в днях. count_c и count_t — числа пользователей контрольной группы и группы варианта. mean_c и mean_t — выборочные средние, variance_c и variance_t — выборочные дисперсии для соответствующих групп. Пустая ячейка означает отсутствие значения.

Набор подготовили C. H. Bryan Liu и соавторы. [Документация авторов](https://github.com/liuchbryan/oce-dataset) · [Оригинальный файл](https://osf.io/download/hq8sc/).
